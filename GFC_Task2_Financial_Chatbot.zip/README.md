# GFC Financial Chatbot Prototype

## Purpose
This is a simplified rule-based prototype for Task 2 of the BCG GenAI project.
It responds to predefined financial questions using the financial data analyzed in Task 1.

## Predefined queries
1. What was Microsoft's revenue in 2025?
2. What was Tesla's net income in 2025?
3. What was Apple's revenue in 2025?
4. How did Microsoft's net income change from 2024 to 2025?
5. How did Tesla's net income change from 2024 to 2025?

## How it works
The chatbot uses Python `if-elif-else` statements to match a user's question with a predefined response.
The financial values come from the Task 1 dataset.

## How to run
1. Install Python.
2. Save `chatbot.py`.
3. Open a terminal in the folder.
4. Run:
   `python chatbot.py`
5. Enter one of the predefined queries.
6. Type `exit` to stop.

## Limitations
- It only understands the predefined queries.
- It does not use a large language model or advanced NLP.
- It does not retrieve live financial data.
- It is a prototype for demonstrating basic chatbot logic.
