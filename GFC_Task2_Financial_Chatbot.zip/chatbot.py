# GFC Financial Chatbot Prototype
# Task 2 - AI-powered Financial Chatbot

financial_data = {
    "Microsoft": {
        2023: {"Revenue": 211915, "Net Income": 72361},
        2024: {"Revenue": 245122, "Net Income": 88136},
        2025: {"Revenue": 281724, "Net Income": 101832},
    },
    "Tesla": {
        2023: {"Revenue": 96773, "Net Income": 14997},
        2024: {"Revenue": 97690, "Net Income": 7091},
        2025: {"Revenue": 94827, "Net Income": 3794},
    },
    "Apple": {
        2023: {"Revenue": 383285, "Net Income": 96995},
        2024: {"Revenue": 391035, "Net Income": 93736},
        2025: {"Revenue": 416161, "Net Income": 112010},
    }
}

def simple_chatbot(user_query):
    q = user_query.strip().lower()

    # Predefined query 1
    if q == "what was microsoft's revenue in 2025?":
        return "Microsoft's revenue in 2025 was $281,724 million."

    # Predefined query 2
    elif q == "what was tesla's net income in 2025?":
        return "Tesla's net income in 2025 was $3,794 million."

    # Predefined query 3
    elif q == "what was apple's revenue in 2025?":
        return "Apple's revenue in 2025 was $416,161 million."

    # Predefined query 4
    elif q == "how did microsoft's net income change from 2024 to 2025?":
        old = financial_data["Microsoft"][2024]["Net Income"]
        new = financial_data["Microsoft"][2025]["Net Income"]
        change = ((new - old) / old) * 100
        return f"Microsoft's net income increased from ${old:,} million in 2024 to ${new:,} million in 2025, an increase of {change:.2f}%."

    # Predefined query 5
    elif q == "how did tesla's net income change from 2024 to 2025?":
        old = financial_data["Tesla"][2024]["Net Income"]
        new = financial_data["Tesla"][2025]["Net Income"]
        change = ((new - old) / old) * 100
        return f"Tesla's net income decreased from ${old:,} million in 2024 to ${new:,} million in 2025, a decrease of {abs(change):.2f}%."

    else:
        return ("Sorry, I can only provide information on predefined financial queries. "
                "Try asking about Microsoft, Tesla, or Apple revenue and net income.")

if __name__ == "__main__":
    print("GFC Financial Chatbot Prototype")
    print("Type 'exit' to stop.")
    while True:
        user_query = input("\nYou: ")
        if user_query.lower() == "exit":
            print("Chatbot: Goodbye!")
            break
        print("Chatbot:", simple_chatbot(user_query))
